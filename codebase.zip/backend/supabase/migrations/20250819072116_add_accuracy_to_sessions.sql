-- Add accuracy column to sessions table
alter table sessions
add column accuracy float4;
