export interface FillerWordTrends {
  [key: string]: {
    current: number;
    previous: number;
  };
}
