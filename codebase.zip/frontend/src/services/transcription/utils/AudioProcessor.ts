/**
 * AudioProcessor - Shared audio conversion utilities for STT modes.
 *
 * This module extracts common audio processing patterns used by:
 * - CloudAssemblyAI (Float32 → Int16)
 * - OnDeviceWhisper (Float32 → WAV)
 *
 * Centralizing these utilities reduces code duplication and ensures
 * consistent audio handling across all transcription modes.
 */

/**
 * Convert Float32Array audio samples to Int16Array.
 * Used by CloudAssemblyAI for WebSocket streaming.
 *
 * @param float32Array - Audio samples in Float32 format (-1.0 to 1.0)
 * @returns Int16Array suitable for WebSocket transmission
 */
export function floatToInt16(float32Array: Float32Array): Int16Array {
    const int16Array = new Int16Array(float32Array.length);
    for (let i = 0; i < float32Array.length; i++) {
        int16Array[i] = Math.max(-32768, Math.min(32767, float32Array[i] * 32767));
    }
    return int16Array;
}

/**
 * Convert Float32Array audio samples to WAV-formatted Uint8Array.
 * Used by OnDeviceWhisper for inference.
 *
 * @param samples - Audio samples in Float32 format
 * @param sampleRate - Sample rate (default: 16000 Hz for Whisper)
 * @returns WAV file as Uint8Array
 */
export function floatToWav(samples: Float32Array, sampleRate = 16000): Uint8Array {
    const buffer = new ArrayBuffer(44 + samples.length * 2);
    const view = new DataView(buffer);

    // RIFF chunk descriptor
    writeString(view, 0, 'RIFF');
    view.setUint32(4, 36 + samples.length * 2, true);
    writeString(view, 8, 'WAVE');

    // fmt sub-chunk
    writeString(view, 12, 'fmt ');
    view.setUint32(16, 16, true); // Subchunk1Size (16 for PCM)
    view.setUint16(20, 1, true);  // AudioFormat (1 for PCM)
    view.setUint16(22, 1, true);  // NumChannels (1 for mono)
    view.setUint32(24, sampleRate, true); // SampleRate
    view.setUint32(28, sampleRate * 2, true); // ByteRate
    view.setUint16(32, 2, true);  // BlockAlign
    view.setUint16(34, 16, true); // BitsPerSample

    // data sub-chunk
    writeString(view, 36, 'data');
    view.setUint32(40, samples.length * 2, true);

    // Write samples (convert Float32 to Int16)
    let offset = 44;
    for (let i = 0; i < samples.length; i++) {
        const s = Math.max(-1, Math.min(1, samples[i]));
        view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7FFF, true);
        offset += 2;
    }

    return new Uint8Array(buffer);
}

/**
 * Write a string to a DataView at the specified offset.
 * Helper for WAV header generation.
 */
function writeString(view: DataView, offset: number, string: string): void {
    for (let i = 0; i < string.length; i++) {
        view.setUint8(offset + i, string.charCodeAt(i));
    }
}

/**
 * Concatenate multiple Float32Arrays into a single array.
 * Used for accumulating audio chunks before processing.
 *
 * @param arrays - Array of Float32Arrays to concatenate
 * @returns Single concatenated Float32Array
 */
export function concatenateFloat32Arrays(arrays: Float32Array[]): Float32Array {
    const totalLength = arrays.reduce((sum, arr) => sum + arr.length, 0);
    const result = new Float32Array(totalLength);
    let offset = 0;
    for (const arr of arrays) {
        result.set(arr, offset);
        offset += arr.length;
    }
    return result;
}

/**
 * Audio buffer manager for accumulating samples until a minimum threshold.
 * Used by CloudAssemblyAI for buffering before WebSocket send.
 */
export class AudioBuffer {
    private buffer: Int16Array = new Int16Array(0);

    constructor(private readonly minSamples: number = 800) { } // 50ms at 16kHz

    /**
     * Add samples to buffer, returns data if minimum threshold reached.
     * @returns Int16Array to send, or null if still accumulating
     */
    addSamples(samples: Int16Array): Int16Array | null {
        const newBuffer = new Int16Array(this.buffer.length + samples.length);
        newBuffer.set(this.buffer);
        newBuffer.set(samples, this.buffer.length);
        this.buffer = newBuffer;

        if (this.buffer.length >= this.minSamples) {
            const data = this.buffer;
            this.buffer = new Int16Array(0);
            return data;
        }
        return null;
    }

    /**
     * Flush any remaining buffered samples.
     */
    flush(): Int16Array {
        const data = this.buffer;
        this.buffer = new Int16Array(0);
        return data;
    }

    /**
     * Clear the buffer without returning data.
     */
    clear(): void {
        this.buffer = new Int16Array(0);
    }
}
