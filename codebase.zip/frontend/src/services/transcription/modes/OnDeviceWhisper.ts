import logger from '../../../lib/logger';
import { SessionManager, AvailableModels, InferenceSession } from 'whisper-turbo';
import { ITranscriptionMode, TranscriptionModeOptions } from './types';
import { MicStream } from '../utils/types';
import { floatToWav, concatenateFloat32Arrays } from '../utils/AudioProcessor';
import { TranscriptUpdate } from '../TranscriptionService';
import { toast } from 'sonner';

type Status = 'idle' | 'loading' | 'transcribing' | 'stopped' | 'error';

export default class OnDeviceWhisper implements ITranscriptionMode {
  private onTranscriptUpdate: (update: TranscriptUpdate) => void;
  private onModelLoadProgress?: (progress: number) => void;
  private onReady?: () => void;
  private status: Status;
  private transcript: string;
  private session: InferenceSession | null;
  private mic: MicStream | null = null;
  private manager: SessionManager;
  private audioChunks: Float32Array[] = [];
  private isProcessing: boolean = false;
  private processingInterval: NodeJS.Timeout | null = null;

  constructor({ onTranscriptUpdate, onModelLoadProgress, onReady }: TranscriptionModeOptions) {
    if (!onTranscriptUpdate) {
      throw new Error("onTranscriptUpdate callback is required for OnDeviceWhisper.");
    }
    this.onTranscriptUpdate = onTranscriptUpdate;
    this.onModelLoadProgress = onModelLoadProgress;
    this.onReady = onReady;
    this.status = 'idle';
    this.transcript = '';
    this.session = null;
    this.manager = new SessionManager();
    logger.info('[OnDeviceWhisper] Initialized (whisper-turbo backend).');
  }

  public async init(): Promise<void> {
    logger.info('[OnDeviceWhisper] Initializing model...');
    this.status = 'loading';

    try {
      logger.info(`[OnDeviceWhisper] Loading model: ${AvailableModels.WHISPER_TINY}`);

      // Trigger initial progress to ensure UI shows "Downloading..." immediately
      if (this.onModelLoadProgress) {
        this.onModelLoadProgress(0);
      }

      const result = await this.manager.loadModel(
        AvailableModels.WHISPER_TINY,
        () => {
          logger.info('[OnDeviceWhisper] Model loaded callback triggered.');
        },
        (progress: number) => {
          if (this.onModelLoadProgress) {
            this.onModelLoadProgress(progress);
          }
        }
      );

      if (result.isErr) {
        throw result.error;
      }

      this.session = result.value;
      this.status = 'idle';
      logger.info('[OnDeviceWhisper] Model loaded successfully.');

      // Show toast notification
      toast.success('Model ready! You can now start your session.');

      // Notify that the service is ready
      if (this.onReady) {
        this.onReady();
      }
    } catch (error) {
      logger.error({ err: error }, '[OnDeviceWhisper] Failed to load model.');
      this.status = 'error';
      throw error;
    }
  }

  public async startTranscription(mic: MicStream): Promise<void> {
    if (!mic) {
      logger.error('[OnDeviceWhisper CRITICAL] startTranscription called with null/undefined mic!');
      throw new Error('MicStream is required for OnDeviceWhisper');
    }
    if (typeof mic.onFrame !== 'function') {
      logger.error('[OnDeviceWhisper CRITICAL] MicStream missing onFrame method!');
      throw new Error('Invalid MicStream: missing onFrame method');
    }
    this.mic = mic;
    logger.info('[OnDeviceWhisper] startTranscription() called.');
    if (this.status !== 'idle') {
      logger.warn(`[OnDeviceWhisper] Unexpected status: ${this.status}, expected 'idle'`);
    }
    if (!this.session) {
      logger.error('[OnDeviceWhisper] session is null - model may not have loaded. Call init() first.');
      throw new Error('OnDeviceWhisper session not initialized. Call init() first.');
    }
    this.status = 'transcribing';
    this.audioChunks = [];
    this.transcript = '';

    // Subscribe to microphone frames
    mic.onFrame((frame: Float32Array) => {
      // Copy the frame to avoid buffer detachment issues
      this.audioChunks.push(frame.slice(0));
    });

    // Start processing loop (every 1 second)
    this.processingInterval = setInterval(() => {
      this.processAudio();
    }, 1000);

    logger.info('[OnDeviceWhisper] Streaming started.');
  }

  private async processAudio(): Promise<void> {
    if (this.isProcessing) {
      return; // Already processing, skip
    }
    if (!this.session) {
      logger.error('[OnDeviceWhisper] processAudio called but session is null!');
      return;
    }
    if (this.audioChunks.length === 0) {
      return; // No audio to process
    }

    this.isProcessing = true;

    try {
      // Concatenate all chunks using shared utility
      const concatenated = concatenateFloat32Arrays(this.audioChunks);

      const wavData = floatToWav(concatenated);

      // Perform transcription on NEW audio only
      const result = await this.session.transcribe(wavData, false, {});

      if (result.isErr) {
        throw result.error;
      }

      // Append new text to transcript (incremental)
      const newText = result.value.text || '';
      if (newText.trim()) {
        // Append with space if transcript already has content
        this.transcript = this.transcript ? `${this.transcript} ${newText}` : newText;
        this.onTranscriptUpdate({ transcript: { final: this.transcript } });
      }

      // CRITICAL FIX: Clear the buffer to prevent quadratic growth
      this.audioChunks = [];

    } catch (err) {
      logger.error({ err }, '[OnDeviceWhisper] Transcription processing failed.');
    } finally {
      this.isProcessing = false;
    }
  }

  public async stopTranscription(): Promise<string> {
    logger.info('[OnDeviceWhisper] stopTranscription() called.');

    if (this.processingInterval) {
      clearInterval(this.processingInterval);
      this.processingInterval = null;
    }

    if (this.mic) {
      // We don't need to explicitly unsubscribe as mic.stop() usually handles it,
      // but good practice to clear references.
      this.mic = null;
    }

    // Process any remaining audio
    await this.processAudio();

    this.status = 'stopped';
    return this.transcript;
  }

  public async getTranscript(): Promise<string> {
    return this.transcript;
  }
}
