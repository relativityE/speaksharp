// Mock for whisper-turbo library
export const SessionManager = class { };
export const AvailableModels = {
    WHISPER_TINY: 'tiny'
};
export const InferenceSession = class { };
