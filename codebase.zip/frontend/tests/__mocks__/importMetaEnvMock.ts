export default {
  env: {
    VITE_STRIPE_PRICE_ID: 'price_12345_test',
  },
};
