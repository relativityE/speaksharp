import type { Vi } from 'vitest';

declare global {
  const vi: Vi;
}