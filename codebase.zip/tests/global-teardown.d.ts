export default function globalTeardown(): Promise<void>;
