export const PORTS = {
    DEV: 5173,
    PREVIEW: 4173,
};
