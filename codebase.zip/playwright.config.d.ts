declare const _default: import("playwright/test").PlaywrightTestConfig<{}, {}>;
export default _default;
