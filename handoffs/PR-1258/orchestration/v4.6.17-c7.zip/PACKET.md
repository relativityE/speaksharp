# Orchestration app v4.6.17 C7 — CI-to-review qualification repair

Status: **incremental source review packet only. Not accepted, installed, or deployable.**

- Source branch: `fix/rwt-orch-successor-6060194201`
- Commit: `344648f40b296a060c760bc8ef581d6a1ff01a3e`
- Tree: `e67dc0e521742a6cc281d2d716ee59284a745869`
- Parent: `afb031450c32203a43f07747004497c0c01ba915`
- Tracked source files: 40; per-file SHA-256 and byte counts are in `MANIFEST.json`.
- Source archive SHA-256: `3dfb985f3da403a3f48286d2e572e3f4fe9602d6f5c080c07d956d1b5dc647d4` (294,742 bytes).

## P1 repairs

- A Ready, non-draft PR can queue the authorized review follow-up when the newest exact-head CI run has successful `report` and `full-evidence` jobs, even if downstream review/merge qualification makes the overall workflow fail. Missing, failed, skipped, stale-head, or mismatched-attempt engineering evidence remains HOLD.
- The watcher chooses the newest workflow run by creation time/run ID, then compares attempts only within that same run ID. An older run's higher attempt can no longer hide a newer run. Follow-up deduplication is bound to the exact run/attempt/head evidence signature.

## Verification

- `python3 -m unittest discover -q`: 319 passed in 61.616s.
- Three focused CI transition tests passed; `node test_ui.js`, Python compilation, schema parse, shell syntax, and `git diff --check` passed.
- Regressions cover downstream review failure with engineering success, newer run ID attempt 1 superseding older run attempt 2, engineering failure HOLD, full-lane evidence, exact run/attempt detail readback, and normal PM worker execution/restart idempotence.

## Remaining HOLDs

The source fixes do not prove actual installed behavior. Independent review, live configured-agent delivery/receipt/action/recovery, five host tests, installed restart/rollback acceptance, Security reviewer routing, and aggregate cross-watcher request-budget acceptance remain open. No installation/restart, PR, merge, deployment, or Production action occurred. The #1573 coordination gate remains open until the installed unattended CI→review→result→qualification path is observed.
