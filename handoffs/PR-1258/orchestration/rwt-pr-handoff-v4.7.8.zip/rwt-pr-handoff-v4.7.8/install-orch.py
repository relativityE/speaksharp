#!/usr/bin/env python3
"""Install once; launch and restart through the user's macOS LaunchAgent."""
import argparse
import json
import os
from pathlib import Path
import plistlib
import shutil
import subprocess
import sys
import tempfile
import webbrowser
import package_integrity

VERSION = '4.7.8'
LABEL = 'com.speaksharp.orch'


def launch_spec(root, python, path):
    return {'Label': LABEL, 'ProgramArguments': [python, str(root / 'installed-service.py')],
            'WorkingDirectory': str(root), 'RunAtLoad': True, 'KeepAlive': True,
            'ThrottleInterval': 30, 'EnvironmentVariables': {'PATH': path, 'RWT_CONTROL_ISSUE': '1593',
                                                           'RWT_WATCH_ISSUES': '1304,1360,1593'},
            'StandardOutPath': str(root / '.agent-work' / 'service.log'),
            'StandardErrorPath': str(root / '.agent-work' / 'service.log')}


def install_files(source, target):
    errors = package_integrity.verify(source)
    if errors:
        raise RuntimeError('; '.join(errors))
    if source.resolve() == target.resolve():
        return
    target.mkdir(parents=True, exist_ok=True)
    # Never overwrite or delete private state, pairing, receipts, uploads or handoffs.
    manifest = json.loads((source / 'PACKAGE-MANIFEST.json').read_text())
    for entry in manifest['files'] + [{'path': 'PACKAGE-MANIFEST.json'}]:
        rel = Path(entry['path'])
        dst = target / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        if dst.is_symlink():
            raise RuntimeError('Installed source path redirected: ' + str(rel))
        fd, temp = tempfile.mkstemp(dir=dst.parent, prefix='.install-')
        try:
            with os.fdopen(fd, 'wb') as out:
                out.write((source / rel).read_bytes())
            os.chmod(temp, (source / rel).stat().st_mode & 0o777)
            os.replace(temp, dst)
        finally:
            if os.path.exists(temp):
                os.unlink(temp)
    if package_integrity.verify(target):
        raise RuntimeError('Installed package readback failed')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    source = Path(__file__).resolve().parent
    if args.check:
        errors = package_integrity.verify(source)
        print(json.dumps({'version': VERSION, 'package_valid': not errors, 'errors': errors}))
        return bool(errors)
    if sys.platform != 'darwin':
        raise SystemExit('The persistent installer targets macOS. Offline tests run on any Python 3.10+ host.')
    target = Path.home() / 'SW_Dev' / ('rwt-pr-handoff-v' + VERSION)
    agents = Path.home() / 'Library' / 'LaunchAgents'
    plist = agents / (LABEL + '.plist')
    if plist.exists():
        existing = plistlib.loads(plist.read_bytes())
        if existing.get('ProgramArguments', [None, None])[1:] == [str(target / 'installed-service.py')]:
            webbrowser.open('http://127.0.0.1:4317/')
            print('Orch already installed; active source/state were not overwritten.')
            return 0
        raise RuntimeError('A different installed service requires an idle-boundary upgrade; no active source was overwritten')
    install_files(source, target)
    state = target / '.agent-work'
    state.mkdir(mode=0o700, exist_ok=True)
    os.chmod(state, 0o700)
    # Shell-derived executable locations survive launchd's minimal environment.
    executable_dirs = [str(Path(sys.executable).resolve().parent)]
    for name in ('gh', 'codex', 'claude'):
        found = shutil.which(name)
        if found:
            executable_dirs.append(str(Path(found).parent))
    path = ':'.join(dict.fromkeys(executable_dirs + ['/opt/homebrew/bin', '/usr/local/bin', '/usr/bin', '/bin']))
    agents = Path.home() / 'Library' / 'LaunchAgents'
    agents.mkdir(parents=True, exist_ok=True)
    plist = agents / (LABEL + '.plist')
    # A running installed instance is never replaced in-place by installer commands.
    if plist.exists():
        existing = plistlib.loads(plist.read_bytes())
        if existing.get('ProgramArguments') == launch_spec(target, sys.executable, path)['ProgramArguments']:
            webbrowser.open('http://127.0.0.1:4317/')
            print('Orch is already installed; its service owns startup and recovery.')
            return 0
        raise RuntimeError('Existing LaunchAgent requires the idle-boundary service upgrade; no active process was reset')
    fd = os.open(plist, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    with os.fdopen(fd, 'wb') as out:
        plistlib.dump(launch_spec(target, sys.executable, path), out)
    subprocess.run(['launchctl', 'bootstrap', f'gui/{os.getuid()}', str(plist)], check=True)
    webbrowser.open('http://127.0.0.1:4317/')
    print('Orch installed and started. Background service discovers the running board, migrates at idle, and restarts at login.')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
