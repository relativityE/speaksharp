#!/usr/bin/env python3
"""Own board startup/idle upgrade without asking the PO to operate scripts."""
import importlib.util
import json
import os
from pathlib import Path
import re
import signal
import sqlite3
import subprocess
import sys
import time
import urllib.request
import webbrowser
from migrate_state import migrate_state

ROOT = Path(__file__).resolve().parent


def http(path, body=None, token=None, port=4317):
    # Local-only, no proxy, redirect or secret output.
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *args):
            return None
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())
    headers = {'Content-Type': 'application/json'}
    if token:
        headers['X-RWT-Control-Token'] = token
    request = urllib.request.Request(f'http://127.0.0.1:{port}' + path,
                                     data=json.dumps(body).encode() if body is not None else None, headers=headers)
    with opener.open(request, timeout=3) as response:
        data = response.read()
    return data.decode() if path == '/' else json.loads(data)


def process_identity(port=4317, run=subprocess.run):
    result = run(['lsof', '-nP', '-a', '-iTCP:' + str(port), '-sTCP:LISTEN', '-Fp'],
                 capture_output=True, text=True, timeout=5)
    pids = {int(line[1:]) for line in result.stdout.splitlines() if re.fullmatch(r'p\d+', line)}
    if len(pids) != 1:
        raise RuntimeError('Cannot verify sole existing board process')
    pid = pids.pop()
    cmd = run(['ps', '-p', str(pid), '-o', 'uid=,command='], capture_output=True, text=True, timeout=5).stdout.strip()
    uid, _, command = cmd.partition(' ')
    if uid != str(os.getuid()) or not re.search(r'(?:^|[ /])server\.py(?:\s|$)', command):
        raise RuntimeError('Existing loopback server is not a verified owned Orch process')
    cwd = run(['lsof', '-a', '-p', str(pid), '-d', 'cwd', '-Fn'], capture_output=True, text=True, timeout=5).stdout
    paths = [Path(line[1:]) for line in cwd.splitlines() if line.startswith('n/')]
    if len(paths) != 1 or not (paths[0] / '.agent-work' / 'state.db').is_file():
        raise RuntimeError('Existing board state directory is unverified')
    return pid, paths[0], command


def idle_reason(live, source):
    if not isinstance(live, dict) or 'transport' not in live:
        return 'Port owner is not an Orch board'
    if any(a.get('status') in ('running', 'claimed', 'delivering') for a in live.get('agents', [])):
        return 'Agent invocation active'
    if any(q.get('status') in ('claimed', 'delivering') for q in live.get('deliveries', [])):
        return 'Delivery invocation active'
    state = Path(source) / '.agent-work'
    with sqlite3.connect(f'{(state / "state.db").as_uri()}?mode=ro', uri=True) as db:
        if db.execute("SELECT 1 FROM pm_action_journal WHERE status IN ('running','unconfirmed') LIMIT 1").fetchone():
            return 'Side-effect journal needs local agent readback before upgrade'
    inbox = state / 'actor-inbox.db'
    if inbox.exists():
        with sqlite3.connect(f'{inbox.as_uri()}?mode=ro', uri=True) as db:
            tables = {r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            if 'worker_actions' in tables and db.execute("SELECT 1 FROM worker_actions WHERE state<>'completed' LIMIT 1").fetchone():
                return 'Dev action still active or uncertain'
    return ''


def adopt_existing(port=4317):
    try:
        live = http('/api/live', port=port)
    except (OSError, ValueError):
        return None
    pid, source, command = process_identity(port)
    if source.resolve() == ROOT.resolve():
        return 'already_running'
    reason = idle_reason(live, source)
    if reason:
        raise RuntimeError(reason)
    match = re.search(r"const CONTROL_TOKEN='([A-Za-z0-9_-]{24,128})'", http('/', port=port))
    if not match:
        raise RuntimeError('Existing board control authentication unavailable')
    token = match.group(1)
    agents = live.get('agents', [])
    paused = {a['agent_id']: bool(a.get('paused')) for a in agents if a.get('agent_id') in ('pm', 'dev')}
    try:
        for actor in ('pm', 'dev'):
            http('/api/pause', {'agent': actor, 'paused': True}, token, port)
        # Verify after pausing: queued work cannot race upgrade admission.
        reason = idle_reason(http('/api/live', port=port), source)
        if reason or process_identity(port) != (pid, source, command):
            raise RuntimeError(reason or 'Port process identity drifted')
        # Retain verified source before interrupt, so an interrupted installer can recover it.
        state = ROOT / '.agent-work'
        state.mkdir(mode=0o700, exist_ok=True)
        (state / 'upgrade-source.json').write_text(json.dumps({'source': str(source), 'paused': paused}))
        os.chmod(state / 'upgrade-source.json', 0o600)
        os.kill(pid, signal.SIGINT)
        for _ in range(50):
            try:
                os.kill(pid, 0)
            except ProcessLookupError:
                break
            time.sleep(.1)
        else:
            raise RuntimeError('Existing board did not exit; no forced kill or migration')
        return source
    except Exception:
        # Resume exactly the old pause states only if the same old process still owns the port.
        try:
            if process_identity(port) == (pid, source, command):
                for actor, value in paused.items():
                    http('/api/pause', {'agent': actor, 'paused': value}, token, port)
        except Exception:
            pass
        raise


def main():
    port = int(os.environ.get('RWT_PORT', '4317'))
    source = adopt_existing(port)
    if source == 'already_running':
        time.sleep(30)
        return 0
    note = ROOT / '.agent-work' / 'upgrade-source.json'
    if source is None and note.exists():
        source = Path(json.loads(note.read_text())['source'])
    migrate_state(ROOT, str(source / '.agent-work' / 'state.db') if source else None)
    # Paused states changed only for the upgrade boundary; restore original preferences in the imported DB.
    if note.exists():
        original = json.loads(note.read_text())
        with sqlite3.connect(ROOT / '.agent-work' / 'state.db') as db:
            for actor, paused in original.get('paused', {}).items():
                db.execute('UPDATE agents SET paused=? WHERE agent_id=?', (int(paused), actor))
    spec = importlib.util.spec_from_file_location('orch_setup', ROOT / 'orch-setup.py')
    setup = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(setup)
    issues = setup.prerequisites(dict(os.environ))
    if issues:
        raise RuntimeError('; '.join(issues))
    env = dict(os.environ, RWT_CONTROL_ISSUE='1593', RWT_WATCH_ISSUES='1304,1360,1593')
    child = subprocess.Popen([sys.executable, str(ROOT / 'server.py')], cwd=ROOT, env=env)
    try:
        for _ in range(50):
            if child.poll() is not None:
                return child.returncode
            try:
                http('/api/live', port=port)
                webbrowser.open(f'http://127.0.0.1:{port}/')
                break
            except (OSError, ValueError):
                time.sleep(.1)
        return child.wait()
    except KeyboardInterrupt:
        child.send_signal(signal.SIGINT)
        return child.wait(timeout=10)


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception as exc:
        print('Orch service recovery HOLD: ' + str(exc), flush=True)
        # LaunchAgent retries; no retry resets, credential or task replay.
        time.sleep(30)
        raise SystemExit(1)
