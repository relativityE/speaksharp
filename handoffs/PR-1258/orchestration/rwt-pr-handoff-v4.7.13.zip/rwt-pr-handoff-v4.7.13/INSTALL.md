# Orch v4.7.13 installation

Only PO downloads and installs. Install under ~/SW_Dev/rwt-pr-handoff-v4.7.13 using the same gh blob download, checksum verification, unzip and python3 orch-setup.py flow as v4.7.11. It starts in this terminal and opens http://127.0.0.1:4317/ after the actual API confirms version 4.7.13. Keep the terminal running. No LaunchAgent or login service is installed.

Before upgrading, stop the old foreground board with Ctrl-C in its terminal when no worker action is in flight. The installer preserves a running board instead of killing active work, explicitly reports an old version, and does not pretend the upgrade occurred. Run the installation block in any directory; it changes into the extracted absolute folder itself.

On a fresh v4.7.13 folder, automatically prefer a verified v4.7.12 migration journal, then v4.7.11, then verified v4.7.10, then the known v4.7.7-candidate source. Preserve database, private pairing and artifacts. Existing target state and an explicit migration override are retained; unknown ambiguous history is not guessed. Original installations remain intact.

Existing gh/Codex login and paired routes remain prerequisites, not repeated setup. First launch announces the new app version through the supported routes and requires real recipient receipts/results. Devs do not install this bundle. Native CLI PM receives current events in its PM queue; an unsupported browser chat cannot be automatically awakened. A stale/unrearmed listener remains an explicit transport blocker, never a fabricated ACK.

Accept the installed upgrade only after the board reports 4.7.13 coordination.7, then a real current CI/review event reaches CLI PM and the intended Dev, with authenticated receipt/result and PM follow-through without PO relay. Offline tests do not substitute for this host proof.
