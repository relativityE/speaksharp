import subprocess
import time
import unittest
from unittest.mock import Mock, patch
import worker_supervisor
import coordination_health


class ForegroundLifecycleTests(unittest.TestCase):
    def test_shutdown_terminates_only_board_owned_children_and_prevents_new_spawns(self):
        child = Mock(pid=999)
        child.poll.return_value = None
        with patch.object(worker_supervisor, 'OWNED_CHILDREN', {999: (child, 'cli_dev', 'session')}), \
             patch.object(worker_supervisor, 'STOPPING', False):
            self.assertEqual(worker_supervisor.stop_owned_workers(), [])
            child.terminate.assert_called_once()
            child.wait.assert_called_once_with(timeout=12)
            self.assertEqual(worker_supervisor.OWNED_CHILDREN, {})
            self.assertTrue(worker_supervisor.STOPPING)
            spawn = Mock()
            self.assertEqual(worker_supervisor.resume_registered('.', 4317, 'codex', spawn=spawn), [])
            spawn.assert_not_called()

    def test_recent_persistent_consumer_does_not_require_a_legacy_listener(self):
        flags = {name: True for name in ('pm_github_control', 'pm_github_review', 'pm_github_ci', 'pm_github_head', 'pm_github_deploy')}
        route = {'configured': True, 'transport': 'local_inbox', 'listener_recent': False,
                 'listener_state': 'waiting_for_rearm', 'live_delivery_proven': True,
                 'worker': {'recent': True, 'status': 'working'}}
        transport = {'pm_configured': True, 'agent_routes': {'app_dev': route, 'cli_dev': route}}
        health = coordination_health.summarize(transport, {'pm': {'status': 'idle'}}, flags)
        self.assertTrue(health['core_ready'])
        transport['agent_routes']['cli_dev'] = {**route, 'live_delivery_proven': False}
        health = coordination_health.summarize(transport, {'pm': {'status': 'idle'}}, flags)
        self.assertFalse(health['core_ready'])
        self.assertIn('wake_unproven', [row['code'] for row in health['issues']])

    def test_dead_unclaimed_resuming_worker_can_recover_without_creating_another_thread(self):
        from pathlib import Path
        worker = {'actor': 'cli_dev', 'session': 'saved', 'thread_id': 'verified-thread',
                  'status': 'resuming', 'pid': 100, 'runtime_pid': 101, 'cwd': str(Path.cwd()), 'seen': time.time() - 61}
        route = {'provider': 'local_inbox', 'session_id': 'saved'}
        self.assertEqual(worker_supervisor.restart_reason(worker, 0, route, lambda _: False), '')
        self.assertTrue(worker_supervisor.restart_reason(worker, 1, route, lambda _: False))
        self.assertTrue(worker_supervisor.restart_reason(worker, 0, route, lambda pid: pid == 101))
        self.assertTrue(worker_supervisor.restart_reason({**worker, 'seen': time.time()}, 0, route, lambda _: False))
