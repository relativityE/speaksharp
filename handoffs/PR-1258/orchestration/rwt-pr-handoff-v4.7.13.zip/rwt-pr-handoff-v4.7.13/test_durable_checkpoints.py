"""Checkpoint retention across polling gaps and historical event replay."""
import json
import unittest
import server
from unittest.mock import patch
from test_regressions import RegressionTests


class DurableCheckpointTests(unittest.TestCase):
    setUp = RegressionTests.setUp
    tearDown = RegressionTests.tearDown

    def poll(self, rows):
        server.set_setting('current_pr', '')
        with patch.object(server, 'WATCH_ISSUES', ''), patch.object(server, 'affected_review_snapshot', return_value={}), \
             patch.object(server, 'fetch_watch_comments', return_value=(rows, None, None)):
            snapshot, error = server.github_watch_snapshot()
            self.assertIsNone(error)
            return snapshot

    def test_empty_poll_keeps_latest_human_checkpoint(self):
        row = {'id': 1, 'body': '#1597 merged; proceed to freeze',
               'updated_at': '2026-10-12T19:18:00Z'}
        self.poll([row])
        self.poll([])
        self.assertEqual(json.loads(server.get_setting('control_checkpoint_context'))[0]['body'], row['body'])

    def test_bot_chatter_cannot_displace_current_dev_packet(self):
        self.poll([{'id': 1, 'body': 'App Dev current packet',
                                              'updated_at': '2026-10-12T19:18:00Z'}])
        self.poll([
            {'id': i, 'body': '<!-- rwt-board-pm:old-instance:1 --> stale replay'}
            for i in range(2, 30)
        ])
        rows = json.loads(server.get_setting('control_checkpoint_context'))
        self.assertEqual([r['id'] for r in rows], [1])

    def test_edited_old_comment_retained_and_older_replay_cannot_replace_it(self):
        newer = {'id': 1, 'body': 'authorization superseded', 'updated_at': '2026-10-12T19:18:00Z'}
        self.poll([newer])
        self.poll([
            {'id': 1, 'body': 'old authorization', 'updated_at': '2026-10-12T15:18:00Z'},
            {'id': 2, 'body': 'historical packet', 'updated_at': '2026-10-12T15:19:00Z'},
        ])
        rows = json.loads(server.get_setting('control_checkpoint_context'))
        self.assertEqual(rows[-1]['body'], 'authorization superseded')
        self.assertEqual(rows[-1]['at'], newer['updated_at'])
