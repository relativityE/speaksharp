# v4.7.13 coordination.7 — Mac trial

PO authorized publication for real-world Mac testing on 2026-10-13. This supersedes the hold on distributing the latest source. It is a trial, not a claim that all recipients have passed installed wake acceptance. Only PO downloads/installs; Devs do not download this bundle.

Includes all saved v4.7.12 repairs plus routine PM review/CI follow-through using pinned PM source acceptance, current-PR provenance and Ops/Beta lifecycle support, and durable observation-outage incidents instead of one historical reminder per event. Original deliveries, callback identities and active writers are preserved. See MAC-ACCEPTANCE.md for the reported-issue matrix and real-host checks.

Foreground install/launch, HTTP-readiness browser opening and verified predecessor migration. No LaunchAgent, login task or service. Keep the launcher terminal running. Existing recipient pairing and CLI sign-in are reused. First launch announces this version through GitHub and supported recipient routes.

Open host proofs: GitHub event to idle-agent wake and matching receipt/result; watcher survival/rearm after runtime compaction; stale/replaced recipient routing; Browser PM inbound delivery. Unsupported browser chats cannot be awakened by a GitHub comment. CLI PM is the unattended coordinator and must handle eligible source review/qualification without PO relay. Missing runtime capability is explicit, not fabricated success.

Migration, merge, deployment, credentials and Production runs retain separate authority. This package changes the coordination tool only.
