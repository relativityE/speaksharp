from test_actor_channels import ActorChannelTests
import server


class CheckpointPreservationTests(ActorChannelTests):
    def test_event_version_and_wake_receipts_preserve_real_task_and_blocker(self):
        self.pair()
        for kind in ('wake-probe', 'event-observation', 'version-handshake'):
            server.update_player_status('app_dev', status='blocked', task='#1595 qualification',
                                       blocker='Exact-head CI pending', work_item_key='PR-1595',
                                       source='verified_checkpoint', checkpoint_at='2026-10-12T13:00:00Z')
            before = server.list_player_status()['app_dev']
            probe = server.probe_actor_route('app_dev')
            with server.con() as db:
                db.execute('UPDATE agent_notifications SET task_id=? WHERE action_id=?', (kind, probe['action_id']))
            self.assertEqual(self.callback(probe, 'receipt', 'actually received')[0], 200)
            self.assertEqual(self.callback(probe, 'result', 'wake=automatic; delivery only')[0], 200)
            self.assertEqual(server.list_player_status()['app_dev'], before)
            with server.con() as db:
                delivered = db.execute('SELECT status,receipt_at,result_at FROM agent_notifications WHERE action_id=?', (probe['action_id'],)).fetchone()
            self.assertEqual(delivered['status'], 'responded')
            self.assertTrue(delivered['receipt_at'])
            self.assertTrue(delivered['result_at'])
