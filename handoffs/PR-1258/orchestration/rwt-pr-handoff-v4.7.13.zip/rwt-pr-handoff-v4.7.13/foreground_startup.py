"""Foreground recovery for the verified last-serving board; open only after readiness."""
import argparse
import json
import os
from pathlib import Path
import plistlib
import subprocess
import time
import urllib.request
import webbrowser


def prepare_foreground(root, env, home=None, run=subprocess.run):
    root = Path(root)
    home = Path(home or Path.home())
    source = root.parent / 'rwt-pr-handoff-v4.7.7-candidate' / '.agent-work' / 'state.db'
    migrated = root.parent / 'rwt-pr-handoff-v4.7.10' / '.agent-work'
    receipt = migrated / 'migration-manifest.json'
    if receipt.is_file() and (migrated / 'state.db').is_file():
        manifest = json.loads(receipt.read_text())
        if manifest.get('completed') is True and manifest.get('source_db') == str(source.resolve()) and manifest.get('target_db') == str(migrated / 'state.db'):
            # Keep any delivery/action journal changes made by the successfully migrated v4.7.10.
            source = migrated / 'state.db'
    # Prefer the latest verified installed board, retaining its current journal and pairing.
    latest = root.parent / 'rwt-pr-handoff-v4.7.11' / '.agent-work'
    latest_receipt = latest / 'migration-manifest.json'
    if latest_receipt.is_file() and (latest / 'state.db').is_file():
        manifest = json.loads(latest_receipt.read_text())
        approved_sources = {
            str((root.parent / name / '.agent-work' / 'state.db').resolve())
            for name in ('rwt-pr-handoff-v4.7.10', 'rwt-pr-handoff-v4.7.7-candidate')
        }
        if (manifest.get('completed') is True
                and manifest.get('source_db') in approved_sources
                and manifest.get('target_db') == str((latest / 'state.db').resolve())):
            source = latest / 'state.db'
    # An installed v4.7.12 trial may contain newer receipts than v4.7.11.
    # Prefer it only with its completed migration journal; never guess from mtime.
    trial = root.parent / 'rwt-pr-handoff-v4.7.12' / '.agent-work'
    trial_receipt = trial / 'migration-manifest.json'
    if trial_receipt.is_file() and (trial / 'state.db').is_file():
        manifest = json.loads(trial_receipt.read_text())
        approved_sources = {
            str((root.parent / name / '.agent-work' / 'state.db').resolve())
            for name in ('rwt-pr-handoff-v4.7.11', 'rwt-pr-handoff-v4.7.10', 'rwt-pr-handoff-v4.7.7-candidate')
        }
        if (manifest.get('completed') is True and manifest.get('source_db') in approved_sources
                and manifest.get('target_db') == str((trial / 'state.db').resolve())):
            source = trial / 'state.db'
    if not (root / '.agent-work' / 'state.db').exists() and not env.get('RWT_MIGRATE_FROM') and source.is_file():
        # Confirmed by last-serving receipts and the owned Mac diagnostic 6124027101.
        env['RWT_MIGRATE_FROM'] = str(source)
    plist = home / 'Library' / 'LaunchAgents' / 'com.speaksharp.orch.plist'
    if not plist.exists():
        return
    spec = plistlib.loads(plist.read_bytes())
    args = spec.get('ProgramArguments', [])
    owned = home / 'SW_Dev' / 'rwt-pr-handoff-v4.7.9' / 'installed-service.py'
    if spec.get('Label') != 'com.speaksharp.orch' or args[1:] != [str(owned)]:
        raise RuntimeError('Unrecognized Orch service registration; source and service preserved')
    state = run(['launchctl', 'print', f'gui/{os.getuid()}/com.speaksharp.orch'],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=5)
    if state.returncode == 0:
        raise RuntimeError('Existing Orch service is loaded; preserve it until verified idle recovery')
    # Retain the inactive registration for audit, but prevent the failed v4.7.9 service at login.
    backup = plist.with_suffix('.plist.disabled-v4.7.9')
    if backup.exists():
        raise RuntimeError('Prior service registration archive already exists; no overwrite')
    plist.rename(backup)


def wait_ready(pid, port, timeout=45, opener=None, alive=None, clock=time.monotonic, pause=time.sleep):
    http = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    opener = opener or http.open
    def process_alive():
        try:
            os.kill(pid, 0)
            return True
        except ProcessLookupError:
            return False
    alive = alive or process_alive
    deadline = clock() + timeout
    while clock() < deadline:
        if not alive():
            raise RuntimeError('Orch exited before HTTP readiness; browser not opened')
        try:
            with opener(f'http://127.0.0.1:{port}/api/live', timeout=1) as response:
                value = json.load(response)
            if isinstance(value, dict) and 'transport' in value and value.get('version') == '4.7.13':
                return value
        except (OSError, ValueError):
            pass
        pause(0.2)
    raise RuntimeError('Orch HTTP readiness timed out; browser not opened')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--pid', type=int, required=True)
    parser.add_argument('--port', type=int, required=True)
    args = parser.parse_args()
    wait_ready(args.pid, args.port)
    print('Orch v4.7.13 HTTP ready. Keep this terminal running for coordination.', flush=True)
    webbrowser.open(f'http://127.0.0.1:{args.port}/')


if __name__ == '__main__':
    main()
