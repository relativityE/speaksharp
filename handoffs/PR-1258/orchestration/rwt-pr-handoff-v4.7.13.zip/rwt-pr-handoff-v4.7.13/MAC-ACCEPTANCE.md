# Reported issues and Mac acceptance — v4.7.13

| Reported issue | Included repair / test evidence | Mac acceptance |
|---|---|---|
| Browser failed to launch / readiness timed out | Actual API readiness and version check, explicit old-board detection | New board13/build7 responds before browser opens |
| Separate setup/launch, directory confusion | One orch-setup.py entry; script-relative paths; foreground launcher | Download/install block works from any folder |
| Migration ambiguous across old folders | Completed journals choose verified12/11/10/7.7 predecessor, retaining private routes/state | Expected old tasks and receipts retained |
| Unwanted LaunchAgent/background login service | Foreground only; no service registration | No new LaunchAgent or login task |
| CLI PM blocked after old error/auth state | Startup readiness distinguishes stale errors from real auth/cleanup holds | CLI PM picks up fresh events |
| Wrong owner/DEADLOCK-5 atomic rejection | Durable source checkpoint and owner/lease reconciliation; read-only recovery | No repeated identical patch failure |
| CI start/end, review required/complete, merged event missed | Durable events, registered/open PR discovery and fingerprints | One real CI/review event enters CLI PM queue |
| PM repeatedly asks PO for Ready/review setup | Delegated ordinary review/CI from exact PM source ACCEPT; same-PR source and Ops/Beta branch support | PM performs eligible next step without PO relay |
| Flood of old wake reminders | Per-recipient/session observation outage incidents; fresh reviews outrank reminders | Old backlog produces bounded escalation, not one post per event |
| Status overwritten by probe/version result | Awareness callbacks cannot change task ownership/checkpoint | Actual work status stays intact |
| Long UUID/action crosses other cards | Wrapping/overflow controls and task-aware labels | Agent cards/details stay readable |
| Listener dies on compaction / session changes | Liveness watchdog, verified saved-consumer resume; explicit outage | Idle wake, compaction and current-recipient identity still require host proof |
| Copy-paste, CLI PM to Browser PM relay | Supported transports + delivery/receipt/result ledger; CLI PM owns eligible follow-through | Full Dev packet to PM disposition to Dev ACK without PO copy-paste |
| Existing Dev watchers need update awareness | First-launch version notice/handshake; no Dev bundle download | Agents observe version and update their own supported listener route |

## One acceptance cycle

1. Install and launch this candidate; board must report4.7.13/coordination.7. Existing logins and preserved routes are reused; no additional PO script setup is requested.
2. CLI PM consumes a real current review/terminal-CI event and reads exact PR head/base. Confirm that the required next review/qualification step executes, or a precise justified blocker is reported.
3. Intended Dev receives the event while idle and returns an event-bound authenticated receipt and result. Submission/issue publication alone is not success.
4. Stop/restart the foreground launcher only at idle; verify state/cursor retained, no duplicate tasks and no old writer replaced. Exercise watcher compaction/rearm and verify recent liveness.
5. Record PASS/FAIL and the concrete route/error. No Production/provider/test run, merge or migration is authorized merely to test the tool.

This matrix records all known complaint classes. Offline tests establish included source behavior; host-only rows remain unproved until exercised on the owned Mac.
