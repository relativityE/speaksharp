from unittest.mock import patch
from test_actor_channels import ActorChannelTests
import server
import coordination_recovery
import time


class ObservationIncidentTests(ActorChannelTests):
    def notice(self, action, task='event-observation', session='same-route'):
        with server.con() as db:
            db.execute("INSERT INTO agent_notifications(notification_key,handoff_id,actor_id,task_id,action_id,target_transport,target_session_id,head,instruction,status,attempts,accepted_at,created_at,updated_at) VALUES(?,0,'cli_dev',?,?,'codex_app_server',?,'','observation','awaiting_receipt',1,?,?,?)",
                       (action, task, action, session, server.now(), server.now(), server.now()))

    def test_historical_observation_burst_has_one_route_recovery_per_phase(self):
        for i in range(20):
            self.notice(f'github-event:{i}:cli_dev')
        server.sweep_agent_delivery_stalls(at=time.time() + 1000)
        server.init_db()
        self.notice('github-event:later:cli_dev')
        server.sweep_agent_delivery_stalls(at=time.time() + 2000)
        with server.con() as db:
            recovery = db.execute("SELECT count(*) FROM queue WHERE delivery_key LIKE 'notification-%' AND recipient='pm'").fetchone()[0]
            notices = db.execute("SELECT status,receipt_at,result_at FROM agent_notifications").fetchall()
        self.assertEqual(recovery, 2)
        self.assertEqual(len(notices), 21)
        self.assertTrue(all(r['status'] == 'awaiting_receipt' and not r['receipt_at'] and not r['result_at'] for r in notices))

    def test_other_session_and_actual_task_keep_separate_recovery(self):
        self.notice('event-a')
        self.notice('event-b', session='other-route')
        self.notice('real-task', task='review-task')
        server.sweep_agent_delivery_stalls(at=time.time() + 1000)
        with server.con() as db:
            self.assertEqual(db.execute("SELECT count(*) FROM queue WHERE delivery_key LIKE 'notification-%'").fetchone()[0], 6)

    def test_partial_result_never_settles_other_unacknowledged_delivery(self):
        self.notice('event-a')
        self.notice('event-b')
        server.sweep_agent_delivery_stalls(at=time.time() + 1000)
        token = server._notification_callback_token('event-a', 'cli_dev', 'same-route')
        payload = {'action_id': 'event-a', 'actor_id': 'cli_dev', 'session_id': 'same-route', 'evidence': 'seen'}
        self.assertEqual(server.record_agent_task_callback({**payload, 'stage': 'receipt'}, token)[0], 200)
        self.assertEqual(server.record_agent_task_callback({**payload, 'stage': 'result'}, token)[0], 200)
        with server.con() as db:
            ids = [r[0] for r in db.execute('SELECT DISTINCT fallback_queue_id FROM agent_notifications')]
            self.assertEqual(len(ids), 1)
            self.assertEqual(db.execute('SELECT status FROM queue WHERE id=?', (ids[0],)).fetchone()[0], 'queued')
            self.assertEqual(db.execute("SELECT status FROM agent_notifications WHERE action_id='event-b'").fetchone()[0], 'awaiting_receipt')

    def test_fully_reconciled_incident_can_report_a_later_outage(self):
        self.notice('event-a')
        server.sweep_agent_delivery_stalls(at=time.time() + 1000)
        token = server._notification_callback_token('event-a', 'cli_dev', 'same-route')
        payload = {'action_id': 'event-a', 'actor_id': 'cli_dev', 'session_id': 'same-route', 'evidence': 'seen'}
        server.record_agent_task_callback({**payload, 'stage': 'receipt'}, token)
        server.record_agent_task_callback({**payload, 'stage': 'result'}, token)
        self.notice('event-new-outage')
        server.sweep_agent_delivery_stalls(at=time.time() + 2000)
        with server.con() as db:
            self.assertEqual(db.execute("SELECT count(*) FROM queue WHERE delivery_key LIKE 'notification-%'").fetchone()[0], 4)

    def test_grouped_recovery_retains_original_context_and_yields_to_real_reviews(self):
        self.notice('original')
        self.notice('other')
        server.sweep_agent_delivery_stalls(at=time.time() + 1000)
        reminder = next(q for q in server.list_queue() if q['delivery_key'].startswith('notification-observation-fallback:'))
        context = coordination_recovery.context(server.con, server.actor_channels, reminder)
        self.assertEqual(context['original_notification']['action_id'], 'original')
        self.assertEqual(context['observation_incident']['outstanding_count'], 2)
        server.set_agent('pm', status='idle')
        aid = server.add_activity('GITHUB', 'new review', 'pm')
        review = server.enqueue(aid, 'pm', 'new review', source_actor='GITHUB')
        self.assertEqual(server.next_queue('pm')['id'], review)


class EventQueueRecoveryTests(ActorChannelTests):
    def test_unread_awareness_coalesces_but_a_presented_notice_is_preserved(self):
        self.pair()
        server.persist_event_notifications('old CI snapshot', event_key='old')
        with server.con() as db:
            first = dict(db.execute("SELECT * FROM agent_notifications WHERE actor_id='app_dev' AND task_id='event-observation'").fetchone())
        server.persist_event_notifications('new review snapshot', event_key='new')
        with server.con() as db:
            self.assertEqual(db.execute('SELECT status FROM agent_notifications WHERE action_id=?', (first['action_id'],)).fetchone()[0], 'superseded')
        visible = server.actor_inbox('app_dev', first['target_session_id'], self.token())
        self.assertEqual(len(visible), 1)
        self.assertIn('new review snapshot', visible[0]['body'])
        server.persist_event_notifications('later merge snapshot', event_key='later')
        with server.con() as db:
            self.assertEqual(db.execute('SELECT status FROM agent_notifications WHERE action_id=?', (visible[0]['action_id'],)).fetchone()[0], 'awaiting_receipt')

    def test_repeating_old_event_cannot_supersede_newer_inbox_notice(self):
        self.pair()
        server.persist_event_notifications('old', event_key='old')
        server.persist_event_notifications('new', event_key='new')
        server.persist_event_notifications('old', event_key='old')
        with server.con() as db:
            rows = [dict(row) for row in db.execute("SELECT * FROM agent_notifications WHERE actor_id='app_dev' AND status='awaiting_receipt'")]
        self.assertEqual(len(rows), 1)
        self.assertIn('new', rows[0]['instruction'])

    def test_settled_original_notification_is_in_current_turn_context(self):
        self.pair()
        original = server.probe_actor_route('app_dev')
        self.callback(original, 'receipt', 'received')
        self.callback(original, 'result', 'wake=automatic; observed')
        for _ in range(25):
            later = server.probe_actor_route('app_dev')
            self.callback(later, 'receipt', 'received')
            self.callback(later, 'result', 'wake=automatic; observed')
        context = coordination_recovery.context(server.con, server.actor_channels,
                                               {'delivery_key': 'task-result:' + original['action_id']})
        self.assertEqual(context['original_notification']['action_id'], original['action_id'])
        self.assertEqual(context['original_notification']['status'], 'responded')
        self.assertTrue(context['original_notification']['receipt_at'])
        self.assertTrue(context['original_notification']['result_at'])
        self.assertNotIn('inbox_token', str(context))
        self.assertNotIn('callback_token', str(context))

    def test_current_github_event_preempts_historical_observation_reminders(self):
        aid = server.add_activity('SYSTEM', 'old awareness reminder', 'pm')
        old = server.enqueue(aid, 'pm', 'old awareness reminder', source_actor='SYSTEM',
                             delivery_key='notification-board-fallback:old')
        aid = server.add_activity('GITHUB', '#1596 new source review packet', 'pm')
        new = server.enqueue(aid, 'pm', '#1596 new source review packet', source_actor='GITHUB')
        self.assertEqual(server.next_queue('pm')['id'], new)
        self.assertEqual(next(x for x in server.list_queue() if x['id'] == old)['status'], 'queued')

    def test_real_result_settles_only_uninvoked_fallback(self):
        self.pair()
        for status in ('queued', 'delivering'):
            probe = server.probe_actor_route('app_dev')
            aid = server.add_activity('SYSTEM', 'reminder', 'pm')
            qid = server.enqueue(aid, 'pm', 'reminder', source_actor='SYSTEM')
            with server.con() as db:
                db.execute('UPDATE agent_notifications SET fallback_queue_id=? WHERE action_id=?', (qid, probe['action_id']))
            if status == 'delivering':
                server.update_queue(qid, status='delivering')
            self.callback(probe, 'receipt', 'received')
            self.callback(probe, 'result', 'wake=automatic; observed')
            row = next(x for x in server.list_queue() if x['id'] == qid)
            self.assertEqual(row['status'], 'superseded' if status == 'queued' else 'delivering')

    def test_native_cli_pm_is_not_sent_an_unpaired_external_self_notice(self):
        with patch.object(server, 'dispatch_event_notifications'):
            server.persist_event_notifications('CI complete; review needed', event_key='fresh')
        with server.con() as db:
            actors = {r['actor_id'] for r in db.execute('SELECT actor_id FROM agent_notifications')}
        self.assertEqual(actors, {'app_dev', 'cli_dev', 'browser_pm'})
