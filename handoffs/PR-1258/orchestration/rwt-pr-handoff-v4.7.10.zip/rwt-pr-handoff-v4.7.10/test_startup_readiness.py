"""Routine restart must restore coordination, while keeping task-level uncertainty."""
from unittest.mock import patch
import server
from test_comms import CommsTests


class StartupReadinessTests(CommsTests):
    def test_first_launch_announces_version_once_and_requires_real_actor_acks(self):
        self.enable_real_publication()
        with patch.object(server, 'gh_json', return_value=({'id': 6129990000}, None)) as gh, patch.object(server, 'dispatch_event_notifications'):
            first = server.announce_app_version()
            self.assertEqual(server.announce_app_version(), first)
        self.assertEqual(gh.call_count, 1)
        self.assertIn('ALL AGENTS', gh.call_args.args[0][-1])
        self.assertIn('4.7.10', gh.call_args.args[0][-1])
        with server.con() as db:
            notices = list(db.execute("SELECT actor_id,status,receipt_at,result_at FROM agent_notifications WHERE task_id='version-handshake'"))
        self.assertEqual(len(notices), 4)
        self.assertEqual({n['actor_id'] for n in notices}, {'cli_dev','app_dev','cli_pm','browser_pm'})
        self.assertTrue(all(n['receipt_at'] is None and n['result_at'] is None for n in notices))

    def test_version_publication_error_holds_notice_not_whole_coordinator(self):
        self.enable_real_publication()
        server.set_agent('pm', status='idle')
        with patch.object(server, 'gh_json', return_value=(None, 'connection error')), patch.object(server, 'dispatch_event_notifications'):
            qid = server.announce_app_version()
        self.assertEqual(server.get_agent('pm')['status'], 'idle')
        self.assertEqual(next(r for r in server.list_queue() if r['id'] == qid)['status'], 'responded_unpublished')

    def test_verified_login_clears_stale_auth_error(self):
        server.set_agent('pm', status='auth_required')
        with patch.object(server, 'CODEX_AUTH_OK', True):
            self.assertTrue(server.establish_pm_startup_readiness('codex'))
        self.assertEqual(server.get_agent('pm')['status'], 'idle')

    def test_real_auth_failure_remains_visible(self):
        with patch.object(server, 'CODEX_AUTH_OK', False):
            self.assertFalse(server.establish_pm_startup_readiness('codex'))
        self.assertEqual(server.get_agent('pm')['status'], 'auth_required')

    def test_old_pm_error_does_not_block_new_events_after_restart(self):
        old = self.q()
        server.update_queue(old['id'], status='failed', error='Board patch rejected atomically: stale ownership')
        server.set_agent('pm', status='error')
        server.reset_ephemeral_control_state_on_start()
        fresh = self.q()
        self.assertEqual(server.get_agent('pm')['status'], 'idle')
        self.assertEqual(server.next_queue('pm')['id'], fresh['id'])
        self.assertEqual(next(r for r in server.list_queue() if r['id'] == old['id'])['status'], 'failed')

    def test_deliberate_pause_and_cleanup_hold_are_preserved(self):
        server.set_agent('pm', status='error', paused=1)
        server.reset_ephemeral_control_state_on_start()
        self.assertEqual(server.get_agent('pm')['paused'], 1)
        self.assertEqual(server.get_agent('pm')['status'], 'error')
        server.set_agent('pm', paused=0)
        server.set_setting('pm_cleanup_unverified', 'group identity not verified')
        server.reset_ephemeral_control_state_on_start()
        self.assertEqual(server.get_agent('pm')['status'], 'error')

    def test_dev_preflight_error_can_reconcile_but_never_gains_write_authority(self):
        server.set_agent('dev', status='error')
        server.reset_ephemeral_control_state_on_start()
        self.assertEqual(server.get_agent('dev')['status'], 'idle')
        self.assertEqual(server.get_setting('dev_assignment_reconciled'), '0')

    def test_invoked_uncertain_dev_is_not_reset(self):
        q = self.q()
        server.update_queue(q['id'], recipient='dev', status='failed', launch_attempted_at=server.now(), error='uncertain write')
        server.set_agent('dev', status='error')
        server.reset_ephemeral_control_state_on_start()
        self.assertEqual(server.get_agent('dev')['status'], 'error')

    def test_watching_survives_without_rewriting_preserved_task_owners(self):
        prior = {w['item_key']: (w['owner'], w['branch']) for w in server.list_work_items()}
        server.reset_ephemeral_control_state_on_start()
        after = {w['item_key']: (w['owner'], w['branch']) for w in server.list_work_items()}
        self.assertEqual(after, prior)
        self.assertEqual(server.get_setting('github_watch_snapshot'), '')
