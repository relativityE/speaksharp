import io
import json
from pathlib import Path
import plistlib
import sqlite3
import tempfile
import unittest
from types import SimpleNamespace
from foreground_startup import prepare_foreground, wait_ready
from migrate_state import migrate_state


class ForegroundTests(unittest.TestCase):
    def test_ten_sources_restore_verified_board_and_retain_private_pairing(self):
        with tempfile.TemporaryDirectory() as directory:
            home = Path(directory)
            parent = home / 'SW_Dev'
            for version in ['4.6.16', '4.6.17', '4.7.0', '4.7.1', '4.7.2', '4.7.3', '4.7.5', '4.7.6', '4.7.7-candidate', '4.7.9']:
                state = parent / ('rwt-pr-handoff-v' + version) / '.agent-work'
                state.mkdir(parents=True)
                with sqlite3.connect(state / 'state.db') as db:
                    db.execute('CREATE TABLE marker(value TEXT)')
                    db.execute('INSERT INTO marker VALUES (?)', (version,))
            source = parent / 'rwt-pr-handoff-v4.7.7-candidate' / '.agent-work'
            pairing = source / 'agent-routes.json'
            pairing.write_text('{"existing": "route"}')
            pairing.chmod(0o600)
            root = parent / 'rwt-pr-handoff-v4.7.10'
            root.mkdir()
            env = {}
            prepare_foreground(root, env, home)
            migrated = migrate_state(root, env['RWT_MIGRATE_FROM'])
            self.assertEqual(migrated, source / 'state.db')
            with sqlite3.connect(root / '.agent-work' / 'state.db') as db:
                self.assertEqual(db.execute('SELECT value FROM marker').fetchone()[0], '4.7.7-candidate')
            self.assertEqual((root / '.agent-work' / 'agent-routes.json').read_bytes(), pairing.read_bytes())
            self.assertTrue((source / 'state.db').exists())
            self.assertTrue(json.loads((root / '.agent-work' / 'migration-manifest.json').read_text())['completed'])

    def test_browser_readiness_waits_through_connection_refusal_and_wrong_version(self):
        responses = [OSError('not yet'), {'version': '4.7.9', 'transport': {}}, {'version': '4.7.10', 'transport': {}}]
        def opener(*args, **kwargs):
            value = responses.pop(0)
            if isinstance(value, Exception):
                raise value
            return io.StringIO(json.dumps(value))
        ready = wait_ready(1, 4317, opener=opener, alive=lambda: True, pause=lambda _: None)
        self.assertEqual(ready['version'], '4.7.10')
        self.assertFalse(responses)

    def test_child_exit_and_timeout_do_not_report_ready(self):
        with self.assertRaisesRegex(RuntimeError, 'exited'):
            wait_ready(1, 4317, alive=lambda: False)
        with self.assertRaisesRegex(RuntimeError, 'timed out'):
            wait_ready(1, 4317, timeout=0)

    def test_loaded_service_preserved_inactive_owned_registration_archived(self):
        with tempfile.TemporaryDirectory() as directory:
            home = Path(directory)
            plist = home / 'Library' / 'LaunchAgents' / 'com.speaksharp.orch.plist'
            plist.parent.mkdir(parents=True)
            plist.write_bytes(plistlib.dumps({'Label': 'com.speaksharp.orch', 'ProgramArguments': ['python3', str(home / 'SW_Dev' / 'rwt-pr-handoff-v4.7.9' / 'installed-service.py')]}))
            with self.assertRaisesRegex(RuntimeError, 'loaded'):
                prepare_foreground(home / 'SW_Dev' / 'rwt-pr-handoff-v4.7.10', {}, home, run=lambda *a, **kw: SimpleNamespace(returncode=0))
            self.assertTrue(plist.exists())
            prepare_foreground(home / 'SW_Dev' / 'rwt-pr-handoff-v4.7.10', {}, home, run=lambda *a, **kw: SimpleNamespace(returncode=1))
            self.assertFalse(plist.exists())
            self.assertTrue(plist.with_suffix('.plist.disabled-v4.7.9').exists())


if __name__ == '__main__':
    unittest.main()
