# deadlock.5 verification — 2026-10-07 (candidate 2: isolated repair)

Python regression suite: **226 passed** (196 from the first deadlock.5 checkpoint + 30 new in `test_deadlock5.py`). Node UI smoke: **passed**. Run on the CLI Dev Mac under the shared `host-interlock` lease, from a scratch copy of this bundle with loopback-only ephemeral ports and a temporary state DB per test. No live board, installed app, GitHub write or PR lifecycle was touched.

The new tests cover:
- pre-invocation recovery: exactly one recovery; exempt from the depth cap and `auto_handoff=0`; restart sweep of a crash-owed recovery; historical failures not swept; a repeated unchanged tuple escalates to a blocker;
- the retry API: refused before and after recovery, still allowed after invocation;
- dispatch and lease: PM `next=dev` to an unresolvable tuple; lease transfer only to a verified tuple, preserved on rejection; successful bootstrap handed to Dev once;
- asks: multi-ask posts; history not replayed; noisy newer events; a generic reply vs typed dispositions; an unpublished reply; numbered external dispositions; one bounded watchdog wake, then a blocker;
- review handoffs: a CLI Dev receipt token bound to its delivery; App Dev token comments; no duplicate delivery;
- `refresh_reviews` through a fake GitHub adapter: parsed plan to executor; canonical dedupe; concurrency; interrupted Ready write resumed after restart; a crashed running row; a lost Draft write; stale/Draft HOLD; observed review; review-completion wake; unsupported kind; instructions/schema/prompt parity;
- the share location in the API, manifests and both prompts.

RED evidence: the new file errors on the captured first checkpoint (no `canonical_key`). Three targeted mutants each fail their tests: restoring the old instruction list, removing the retry guard, and routing recovery through `maybe_handoff` again.

Fixture changes to existing tests: `test_refresh_reviews.py`'s fake now clears `draft` on the Ready mutation, as GitHub does, because deadlock.5 reads Ready back. Two assertions now expect `EXECUTED`/`OBSERVED` result prefixes.

Not verified here: installed-board restart, live worker wake-up after a real preflight failure, a live GitHub refresh, external Browser PM/App Dev receipt in practice, and remote readback of a published packet by the GitHub connector. These need separately authorized installed acceptance. This release adds no merge, deployment, migration or Production-run authority.
