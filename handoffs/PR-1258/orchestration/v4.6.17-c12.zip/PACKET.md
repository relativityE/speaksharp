# Orch v4.6.17 C12 review packet

Candidate: `f19098e0ff54e312e53ba37ae986674c1fc8d4a1`
Tree: `e001124122ce09beb5748c6b26f3899ea32258bf`
Immediate parent: `3ee7bf7358a5c398b4b0e7d840445a16ad688994`
Branch: `fix/rwt-orch-successor-6060194201`; worktree clean after commit.

C12 rejects `cli_dev` routing when its configured app-server session is also the local
agent's non-Codex worker session. It blocks before delivery snapshot, review dispatch,
task dispatch and transport-status success. See `C12_DELTA.md`; `source.tar.gz` contains
the complete candidate source.

Verification: `python3 -m unittest discover -v` — 326 passed in 62.753s; Python compile
and diff checks passed.

Still HOLD: installed app is unchanged; actual Codex route configuration and live receipt /
action must be proven after qualified installation. Security reviewer routing, host tests,
installed restart and rollback remain open. No PR, install, restart, merge, deployment or
Production action is authorized here.
