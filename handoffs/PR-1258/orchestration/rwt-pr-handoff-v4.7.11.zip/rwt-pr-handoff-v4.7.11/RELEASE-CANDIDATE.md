# v4.7.11 release packet

Build: coordination.5. This package replaces the capped-control/installation/checkpoint paths in
v4.7.7-candidate. The full source is in the archive and independently hash-listed by PACKAGE-MANIFEST.json.

Offline regressions cover capped-thread routing and dedupe, new PR discovery, connection-error retention,
rejected ownership recovery, cleanup/paused safeguards, secret-free recovery context, notification coalescing,
foreground startup readiness and preservation of private state. Existing delivery/worker/lease/recovery
regressions remain mandatory. No live GitHub or provider requests occur in the offline tests.

Host acceptance is pending until the local operator installs and returns actual actor receipt/result and
PM continuation after a restart. No claim of automatic wake for an unsupported browser chat is made.

The failed v4.7.9 background service entry point has been removed. No LaunchAgent is created; the inactive owned registration is archived. Both launch commands use the previous foreground setup method.

v4.7.11 fixes the actual API/launcher contract mismatch in v4.7.10. HTTP readiness uses the real live handler version/build; prior migrated state is retained.
