#!/usr/bin/env python3
"""Compatibility installer: use the established foreground setup and launch."""
import argparse
import json
import os
from pathlib import Path
import plistlib
import shutil
import subprocess
import sys
import tempfile
import webbrowser
import package_integrity

VERSION = '4.7.11'
LABEL = 'com.speaksharp.orch'


def install_files(source, target):
    errors = package_integrity.verify(source)
    if errors:
        raise RuntimeError('; '.join(errors))
    if source.resolve() == target.resolve():
        return
    target.mkdir(parents=True, exist_ok=True)
    # Never overwrite or delete private state, pairing, receipts, uploads or handoffs.
    manifest = json.loads((source / 'PACKAGE-MANIFEST.json').read_text())
    for entry in manifest['files'] + [{'path': 'PACKAGE-MANIFEST.json'}]:
        rel = Path(entry['path'])
        dst = target / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        if dst.is_symlink():
            raise RuntimeError('Installed source path redirected: ' + str(rel))
        fd, temp = tempfile.mkstemp(dir=dst.parent, prefix='.install-')
        try:
            with os.fdopen(fd, 'wb') as out:
                out.write((source / rel).read_bytes())
            os.chmod(temp, (source / rel).stat().st_mode & 0o777)
            os.replace(temp, dst)
        finally:
            if os.path.exists(temp):
                os.unlink(temp)
    if package_integrity.verify(target):
        raise RuntimeError('Installed package readback failed')


def main():
    # Compatibility entry: the proven foreground setup owns startup and migration.
    return subprocess.call([sys.executable, str(Path(__file__).resolve().parent / 'orch-setup.py'), *sys.argv[1:]])


if __name__ == '__main__':
    raise SystemExit(main())
