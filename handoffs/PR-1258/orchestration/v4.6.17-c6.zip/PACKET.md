# Orchestration app v4.6.17 C6 — C4 findings repair candidate

Status: **source review packet only. Not accepted, installed, or deployable.**

- Source branch: `fix/rwt-orch-successor-6060194201`
- Commit: `afb031450c32203a43f07747004497c0c01ba915`
- Tree: `6deefc97b2d9238bc62884fcf6797b83686d3196`
- Parent: `5667bbb30ae6511cf0e477cb0ab199d0e8c2e423`
- Tracked files: 40 with per-file SHA-256 and sizes in `MANIFEST.json`
- Source archive SHA-256: `d146a35ca77d3f808099b871a7451523c207281caa83fa746399049b6c046237`
- Verification: 318 Python tests passed in 65.497s; UI smoke, shell syntax, schema parse, and diff checks passed.

## Source fixes added in C6

- Control comments edited in place now create a new PM wake by comparing body/update time even when the GitHub comment ID is unchanged.
- A recently edited old comment is retained in the bounded cache based on update time rather than being discarded by its low ID.
- The CI integration regression exercises `github_watcher` → the normal PM worker loop/queue claim → source-authorized guarded review refresh → exact-head review result and qualification → restart/duplicate replay.
- Latest-attempt CI selection avoids both obsolete failure blockage and an older success masking an in-progress retry; review polling spans the full active candidate registry without the old fixed lowest-25 starvation.

## Concrete blocker behavior

No configured agent route remains `blocked_transport`; missing source authorization leaves lifecycle work unexecuted and reports a named blocker. The tests prove source behavior using fixtures, not real-agent execution.

## Remaining HOLDs

- Real configured participant endpoints/session identities and task-specific receipt, action, and recovery proof.
- Independent PM review of all R01–R42/F01–F16 rows.
- Actual installed unattended #1570/#1573 CI→review→result→qualification path, restart recovery and rollback proof.
- Configured Security reviewer identity/result and cross-watcher installed request-budget acceptance.
- No install/restart, PR, merge, deployment, or Production action occurred.

See the included closure matrix and receipt. A durable fixture path is not installed unattended acceptance.
