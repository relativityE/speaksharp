"""Read-only failed-checkpoint recovery; no side effects or assignment replay."""
import json
import hashlib


def context(connection, actors):
    with connection() as db:
        journal = [dict(r) for r in db.execute(
            "SELECT action_key,status,kind,pr_number,head,phase,result FROM pm_action_journal "
            "WHERE status IN ('running','unconfirmed','held','failed') ORDER BY updated_at DESC LIMIT 20")]
        deliveries = [dict(r) for r in db.execute(
            "SELECT id,recipient,status,work_item_key,target_branch,target_head,error FROM queue "
            "WHERE status NOT IN ('responded','superseded') ORDER BY id DESC LIMIT 20")]
    try:
        # No inbox bearer tokens, callback secrets or private instruction bodies.
        routes = {actor: {key: route.get(key) for key in ('provider', 'session_id')}
                  for actor, route in actors.read_config()['routes'].items()}
    except Exception as exc:
        routes = {'error': type(exc).__name__}
    return {'routes': routes, 'action_journal': journal, 'deliveries': deliveries,
            'instructions': 'Use actual work_item_key and owner. Null preserves a field; never infer ownership from a display task. '
                            'Do not replay sent or uncertain actions. A blocked historical template is not a current assignment.'}


def recover_preexecution_failures(board):
    """One read-only recovery for a provably unexecuted rejected board patch.

    Never clear an uncertain invocation, cleanup block, active executor or side-effect
    journal. The failed queue entry is retained and dedupe survives process restart.
    """
    if board.get_setting('pm_cleanup_unverified', ''):
        return None
    with board.PROC_LOCK:
        if board.ACTIVE_PM_PROC is not None and board.ACTIVE_PM_PROC.poll() is None:
            return None
    with board.DB_LOCK, board.con() as db:
        db.execute('BEGIN IMMEDIATE')
        if db.execute("SELECT 1 FROM pm_action_journal WHERE status IN ('running','unconfirmed') LIMIT 1").fetchone():
            return None
        if db.execute("SELECT 1 FROM queue WHERE recipient='pm' AND status IN ('claimed','delivering') LIMIT 1").fetchone():
            return None
        row = db.execute("SELECT * FROM queue WHERE recipient='pm' AND status='failed' "
                         "AND error LIKE 'Board patch rejected atomically:%' ORDER BY id DESC LIMIT 1").fetchone()
        if not row:
            return None
        tuples = [dict(r) for r in db.execute(
            'SELECT item_key,owner,branch,state,lease_generation,assignment_generation FROM work_items ORDER BY item_key')]
        signature = json.dumps([row['error'], tuples], sort_keys=True)
        key = 'checkpoint-recovery:' + hashlib.sha256(signature.encode()).hexdigest()
        if db.execute('SELECT 1 FROM queue WHERE delivery_key=?', (key,)).fetchone():
            return None
        # reserve before enqueue: an exception leaves explicit recovery_pending state,
        # not a fabricated successful recovery or mutation replay.
        agent = db.execute("SELECT status,paused FROM agents WHERE agent_id='pm'").fetchone()
        if not agent or agent['paused'] or agent['status'] not in ('idle', 'error'):
            return None
        message = ('CHECKPOINT RECONCILIATION ONLY. Prior board update was rejected before any executor ran. '
                   'Read current control checkpoints plus route/delivery/journal context; return a valid task/player '
                   'patch using the recorded owner. No mutation replay, no historical task replay. Original queue '
                   + str(row['id']) + ': ' + str(row['error'])[:800])
        prior = dict(row)
    aid = board.add_activity('SYSTEM', message, 'pm', 'posted')
    qid = board.enqueue(aid, 'pm', message, source_actor='SYSTEM', auto_handoff=True,
                        delivery_key=key, parent_queue_id=prior['id'])
    if qid:
        board.set_agent('pm', status='idle')
    return qid
