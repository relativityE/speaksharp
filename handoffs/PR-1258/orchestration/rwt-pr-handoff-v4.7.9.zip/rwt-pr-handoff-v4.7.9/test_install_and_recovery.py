"""Actual regression sequences from capped control, new PR and checkpoint deadlocks."""
import importlib.util
import hashlib
import json
from pathlib import Path
import tempfile
from unittest.mock import patch
import unittest
import server
import coordination_recovery
from test_comms import CommsTests


def module(name):
    spec = importlib.util.spec_from_file_location(name, Path(__file__).parent / (name + '.py'))
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


class InstalledRecoveryTests(CommsTests):
    def test_capped_acceptance_routes_publication_to_continuation_once(self):
        self.enable_real_publication()
        q = self.q()
        with patch.object(server, 'CONTROL_ISSUE', 1593), patch.object(server, 'gh_json', return_value=({'id': 6120000000}, None)) as gh:
            self.assertTrue(server.publish_pm_reply(q, 'SOURCE ACCEPT; CLI Dev proceed'))
            self.assertTrue(server.publish_pm_reply(q, 'duplicate turn'))
        self.assertEqual(gh.call_count, 1)
        self.assertTrue(any(str(arg).endswith('issues/1593/comments') for arg in gh.call_args.args[0]))

    def test_new_pr_discovered_without_selected_pr_or_task_assignment(self):
        rows = [{'number': 1594, 'title': 'test(rwt): feedback', 'body': ''},
                {'number': 2000, 'title': 'unrelated feature', 'body': ''}]
        with patch.object(server, 'gh_json', return_value=(rows, None)) as gh:
            self.assertEqual(server.discover_coordination_prs('relativityE/speaksharp'), [1594])
            self.assertEqual(server.discover_coordination_prs('relativityE/speaksharp'), [1594])
        self.assertEqual(gh.call_count, 1)
        self.assertIn(1594, server.cached_coordination_prs())
        self.assertFalse(any(w.get('pr_number') == 1594 for w in server.list_work_items()))

    def test_connection_error_does_not_erase_discovered_prs(self):
        server.set_setting('coordination_discovered_prs', json.dumps({'at': 1, 'numbers': [1594]}))
        with patch.object(server, 'gh_json', return_value=(None, 'connection error')):
            self.assertEqual(server.discover_coordination_prs('relativityE/speaksharp'), [1594])
        self.assertEqual(json.loads(server.get_setting('coordination_discovered_prs'))['at'], 1)

    def test_atomic_patch_failure_gets_one_readonly_recovery_across_restart(self):
        q = self.q()
        server.update_queue(q['id'], status='failed', error='Board patch rejected atomically: app_dev ownership does not match DEADLOCK-5')
        server.set_agent('pm', status='error')
        recovery = coordination_recovery.recover_preexecution_failures(server)
        self.assertIsNotNone(recovery)
        self.assertEqual(server.get_agent('pm')['status'], 'idle')
        self.assertIsNone(coordination_recovery.recover_preexecution_failures(server))
        old = next(x for x in server.list_queue() if x['id'] == q['id'])
        self.assertEqual(old['status'], 'failed')
        new = next(x for x in server.list_queue() if x['id'] == recovery)
        self.assertIn('No mutation replay', new['content'])

    def test_cleanup_or_paused_actor_is_not_reset(self):
        q = self.q()
        server.update_queue(q['id'], status='failed', error='Board patch rejected atomically: bad owner')
        server.set_agent('pm', status='error', paused=1)
        self.assertIsNone(coordination_recovery.recover_preexecution_failures(server))
        server.set_agent('pm', paused=0)
        server.set_setting('pm_cleanup_unverified', 'permission denied')
        self.assertIsNone(coordination_recovery.recover_preexecution_failures(server))
        self.assertEqual(server.get_agent('pm')['status'], 'error')

    def test_recovery_prompt_contains_journal_and_never_inbox_tokens(self):
        class Actors:
            @staticmethod
            def read_config():
                return {'routes': {'cli_dev': {'provider': 'local_inbox', 'session_id': 'known', 'inbox_token': 'SECRET'}}}
        result = coordination_recovery.context(server.con, Actors)
        self.assertEqual(result['routes']['cli_dev']['session_id'], 'known')
        self.assertNotIn('SECRET', json.dumps(result))
        self.assertIn('action_journal', result)

    def test_unsent_event_notices_coalesce_but_sent_notices_are_retained(self):
        with patch.object(server, 'dispatch_event_notifications'):
            server.persist_event_notifications('CI started', event_key='start')
            with server.con() as db:
                db.execute("UPDATE agent_notifications SET attempts=1,status='awaiting_receipt' WHERE actor_id='cli_dev'")
            server.persist_event_notifications('CI complete', event_key='end')
            server.persist_event_notifications('review required', event_key='review')
        with server.con() as db:
            self.assertEqual(db.execute("SELECT count(*) FROM agent_notifications WHERE actor_id='browser_pm' AND attempts=0 AND status='blocked_transport'").fetchone()[0], 1)
            self.assertEqual(db.execute("SELECT count(*) FROM agent_notifications WHERE actor_id='cli_dev' AND status='awaiting_receipt'").fetchone()[0], 1)


class InstallerTests(unittest.TestCase):
    def test_install_copies_verified_code_and_preserves_private_state(self):
        installer = module('install-orch')
        with tempfile.TemporaryDirectory() as temporary:
            source, target = Path(temporary) / 'source', Path(temporary) / 'target'
            source.mkdir()
            code = b'print("fixture")\n'
            (source / 'example.py').write_bytes(code)
            (source / 'PACKAGE-MANIFEST.json').write_text(json.dumps({'files': [
                {'path': 'example.py', 'bytes': len(code), 'sha256': hashlib.sha256(code).hexdigest()}]}))
            state = target / '.agent-work'
            state.mkdir(parents=True)
            (state / 'state.db').write_bytes(b'private state')
            (state / 'agent-routes.json').write_text('private pairing')
            installer.install_files(source, target)
            self.assertEqual((target / 'example.py').read_bytes(), code)
            self.assertEqual((state / 'state.db').read_bytes(), b'private state')
            self.assertEqual((state / 'agent-routes.json').read_text(), 'private pairing')

    def test_launch_agent_is_automatic_and_contains_no_api_keys(self):
        installer = module('install-orch')
        spec = installer.launch_spec(Path('/Users/test/SW_Dev/orch'), '/usr/bin/python3', '/usr/bin:/bin')
        self.assertTrue(spec['RunAtLoad'])
        self.assertTrue(spec['KeepAlive'])
        self.assertEqual(spec['EnvironmentVariables']['RWT_CONTROL_ISSUE'], '1593')
        self.assertNotIn('API_KEY', json.dumps(spec))

    def test_active_invocation_prevents_service_upgrade(self):
        service = module('installed-service')
        reason = service.idle_reason({'transport': {}, 'agents': [{'status': 'running'}]}, Path('/missing'))
        self.assertEqual(reason, 'Agent invocation active')

    def test_real_board_agent_dictionary_is_checked_before_upgrade(self):
        service = module('installed-service')
        reason = service.idle_reason({'transport': {}, 'agents': {'pm': {'status': 'running'}}}, Path('/missing'))
        self.assertEqual(reason, 'Agent invocation active')

    def test_private_state_not_in_install_manifest(self):
        root = Path(__file__).parent
        manifest = json.loads((root / 'PACKAGE-MANIFEST.json').read_text())
        self.assertFalse(any('.agent-work' in f['path'] for f in manifest['files']))


if __name__ == '__main__':
    unittest.main()
