# Orchestration app v4.6.17 C8 — CI qualification and combined-branch repair

Status: **incremental source review packet only. Not accepted, installed, or deployable.**

- Source branch: `fix/rwt-orch-successor-6060194201`
- Commit: `a2b35c819aac85411069c59a11bb48401f877d14`
- Tree: `34288106ce6b97362c382d993f969b45cc85f5ce`
- Parent: `344648f40b296a060c760bc8ef581d6a1ff01a3e`
- Tracked source files: 40; per-file hashes and sizes are in `MANIFEST.json`.
- Source archive SHA-256: `9b2904286fa00e787f16d34d0e034781c5c68ff873dfba01d2754e80383deab1` (295,078 bytes).

## Corrections

1. The CI review wake requires successful `report` and `full-evidence` jobs from the newest exact-head workflow run. Downstream review/merge qualification failures do not circularly block review start. Run creation time/run ID selects the run; attempts are compared only within that run.
2. The guarded executor permits `feat/1258-design-rev2-combined` as one exact branch exception, still requiring source authorization for its exact branch/head/base. Arbitrary combined or feature branches remain rejected.

## Verification

- `python3 -m unittest discover -q`: 320 passed in 71.944s.
- Three CI transition tests and two branch-scope tests passed. UI smoke, Python compilation, schema parse, shell syntax, and diff check passed.

## Remaining HOLDs

This packet does not close all R01–R42/F01–F16 findings or qualify the installed app. Independent review, real configured-agent delivery/receipt/action/recovery, five host tests, installed unattended #1570/#1573 transition, restart/rollback, Security routing, and cross-watcher budget proof remain open. No installation/restart, PR, merge, deployment, or Production action occurred. #1573 remains gated on actual installed unattended CI→reviews→results→qualification without PO relay.
