# Orch app v4.6.17 candidate C4

Status: **source packet for independent review; NOT accepted or installable yet.**

- Source branch: `fix/rwt-orch-successor-6060194201`
- Source commit: `cc3e4b77ff5803658344371580fb2ac0844e5667`
- Tree: `ae4394bd68c5e01f5886895a455d9b0c6e300803`
- Parent: `dbfdd92061324511b7a755ec833c2d17f8a80e4d`
- Source archive: `source.tar.gz` SHA-256 `3217d1b96e2577762a30eda623b117b54fdc5443967871e6a47c63f38971cead`
- Tracked source files: 40 (individual SHA-256 and byte count in `MANIFEST.json`)
- Offline verification: `python3 -m unittest discover -q` — 316 passed, 61.902s; `node test_ui.js` passed; `bash -n start-rwt-handoff.sh`, schema parse, and `git diff --check` passed.

## Candidate changes in this increment

- CI qualification selects the latest attempt for each required workflow: an old failed attempt does not block a successful retry, and a newer in-progress retry prevents an older success from qualifying.
- Rotating review polling covers the full active-candidate registry rather than truncating it to the lowest 25 PR numbers.
- Regressions cover both conditions. Earlier C5 source repairs and the R01–R42/F01–F16 closure matrix are included in the archive.

## Explicit HOLDs

- Actual recipient routing is not configured/proven for all participating agents; no task-specific live delivery, receipt, action, or recovery proof.
- Independent Browser PM source qualification is pending.
- Installed #1570 CI→review→result→qualification transition and installed restart/rollback acceptance are pending.
- External Security reviewer identity/result remains unconfigured.
- Five host tests pass offline, but that does not substitute for installed/live evidence.
- No install/restart, PR, merge, deployment, or Production action has been performed.

See `C4_CLOSURE_MATRIX.md` and `TEST_RECEIPT.md` for row-by-row dispositions and evidence limits.
