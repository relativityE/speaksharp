# Orch 4.6.17-c3 source checkpoint

**Status:** review packet only; not accepted or installed.

- Source commit: `32c241577a29df27f3fb131e66759cc6b6206057`
- Source tree: `5ffecf112d6d8c3e08d0db167a1afd731e98da11`
- Parent: `092452eba33c8e1ed0476d577f67e25173b631e9`
- Branch: `fix/rwt-orch-successor-6060194201`
- Source files: `source/` (exact committed tree)
- Hashes: `MANIFEST.json` (SHA-256 for every archived source file)

## Change and evidence

This increment adds exact Codex actor/session routing over local, Unix-socket, or authenticated WSS app-server connections; authenticated task-aware receipt/result callbacks; durable CI-completion follow-up into the guarded review-refresh journal; and exact-head review-result routing into qualification. It also contains the current C5 source changes and corrected finding dispositions in `source/C4_CLOSURE_MATRIX.md`.

RED/GREEN evidence: `test_ci_completion_starts_one_authorized_review_and_routes_result_without_po_relay` rejects in-progress and failed CI, then passes successful CI through a simulated restart, one guarded refresh, review-result delivery, and qualification advancement without a PO queue. Transport regressions cover wrong/missing routes, actor/session identity, callback ordering and duplication, timeout uncertainty, and local/remote command construction.

Verification on the exact source commit: `python3 -m unittest discover -q` — 314 passed; `node test_ui.js` passed; `bash -n start-rwt-handoff.sh` passed; route schemas parsed; `git diff --check` passed. Five loopback/HTTP tests are included in the suite.

## Explicit HOLDs

- No verified route configuration or task-specific receipt/action from the actual participating agents. Real session IDs, remote endpoints/tokens, and a reachable HTTPS callback URL must be configured and verified.
- Independent Browser PM review and installed restart/rollback acceptance remain pending.
- The #1570 CI → review → result sequence passes offline but has not been observed in the installed app.
- Security review identity/result remains separate and unproven; Code review does not imply Security approval.
- All residual rows in the closure matrix remain open until source, regression, and applicable live evidence are independently accepted.

The replacement installation is already authorized only after complete closure and independent qualification. This candidate does not meet that condition. No installation/restart, PR, merge, deployment, or Production action was performed or requested here.
